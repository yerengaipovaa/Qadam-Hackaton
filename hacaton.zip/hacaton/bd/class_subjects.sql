INSERT INTO `class_subjects` (`id`, `class_id`, `subject_id`, `teacher_id`, `semester`, `academic_year`) VALUES (1, 1, 1, 3, 'Fall', 2026);
