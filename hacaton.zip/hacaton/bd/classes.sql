INSERT INTO `classes` (`id`, `course_id`, `teacher_id`, `semester`, `academic_year`, `schedule`, `room`, `max_students`) VALUES (1, 1, 3, 'Group', 2026, '1 PO G', '', 30);
INSERT INTO `classes` (`id`, `course_id`, `teacher_id`, `semester`, `academic_year`, `schedule`, `room`, `max_students`) VALUES (2, 2, 4, 'Group', 2026, 'faaaaa', '', 30);
INSERT INTO `classes` (`id`, `course_id`, `teacher_id`, `semester`, `academic_year`, `schedule`, `room`, `max_students`) VALUES (3, 3, 2, 'Group', 2026, 'vaaaaaaa', '', 30);
