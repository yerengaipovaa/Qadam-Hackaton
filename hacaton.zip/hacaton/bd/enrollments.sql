INSERT INTO `enrollments` (`id`, `student_id`, `class_id`, `enrollment_date`, `status`) VALUES (1, 3, 1, '2026-02-25 12:21:18', 'active');
INSERT INTO `enrollments` (`id`, `student_id`, `class_id`, `enrollment_date`, `status`) VALUES (2, 4, 1, '2026-02-25 12:21:19', 'active');
INSERT INTO `enrollments` (`id`, `student_id`, `class_id`, `enrollment_date`, `status`) VALUES (3, 5, 2, '2026-02-25 13:38:04', 'active');
INSERT INTO `enrollments` (`id`, `student_id`, `class_id`, `enrollment_date`, `status`) VALUES (4, 6, 2, '2026-02-25 13:38:09', 'active');
INSERT INTO `enrollments` (`id`, `student_id`, `class_id`, `enrollment_date`, `status`) VALUES (5, 8, 3, '2026-02-25 13:40:04', 'active');
INSERT INTO `enrollments` (`id`, `student_id`, `class_id`, `enrollment_date`, `status`) VALUES (6, 7, 3, '2026-02-25 13:40:07', 'active');
INSERT INTO `enrollments` (`id`, `student_id`, `class_id`, `enrollment_date`, `status`) VALUES (7, 9, 3, '2026-02-25 17:26:16', 'active');
