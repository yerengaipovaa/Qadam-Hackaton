INSERT INTO `group_teachers` (`id`, `group_id`, `teacher_id`, `subject_id`, `semester`, `academic_year`, `created_at`) VALUES (1, 2, 3, 1, 'Fall', 2026, '2026-02-25 16:24:29');
INSERT INTO `group_teachers` (`id`, `group_id`, `teacher_id`, `subject_id`, `semester`, `academic_year`, `created_at`) VALUES (2, 2, 4, 2, 'Fall', 2026, '2026-02-25 16:24:29');
INSERT INTO `group_teachers` (`id`, `group_id`, `teacher_id`, `subject_id`, `semester`, `academic_year`, `created_at`) VALUES (3, 2, 2, 3, 'Fall', 2026, '2026-02-25 16:24:29');
INSERT INTO `group_teachers` (`id`, `group_id`, `teacher_id`, `subject_id`, `semester`, `academic_year`, `created_at`) VALUES (4, 1, 3, 3, 'Fall', 2026, '2026-02-25 16:24:44');
INSERT INTO `group_teachers` (`id`, `group_id`, `teacher_id`, `subject_id`, `semester`, `academic_year`, `created_at`) VALUES (5, 1, 4, 1, 'Fall', 2026, '2026-02-25 16:24:44');
INSERT INTO `group_teachers` (`id`, `group_id`, `teacher_id`, `subject_id`, `semester`, `academic_year`, `created_at`) VALUES (6, 3, 4, 1, 'Fall', 2026, '2026-02-25 16:24:58');
INSERT INTO `group_teachers` (`id`, `group_id`, `teacher_id`, `subject_id`, `semester`, `academic_year`, `created_at`) VALUES (7, 3, 2, 2, 'Fall', 2026, '2026-02-25 16:24:58');
