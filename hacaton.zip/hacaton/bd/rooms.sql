INSERT INTO `rooms` (`id`, `room_number`, `building`, `capacity`, `room_type`, `status`, `created_at`) VALUES (1, '101', 'Main Building', 30, 'classroom', 'active', '2026-02-25 18:59:59');
INSERT INTO `rooms` (`id`, `room_number`, `building`, `capacity`, `room_type`, `status`, `created_at`) VALUES (2, '102', 'Main Building', 30, 'classroom', 'active', '2026-02-25 18:59:59');
INSERT INTO `rooms` (`id`, `room_number`, `building`, `capacity`, `room_type`, `status`, `created_at`) VALUES (3, '103', 'Main Building', 30, 'classroom', 'active', '2026-02-25 18:59:59');
INSERT INTO `rooms` (`id`, `room_number`, `building`, `capacity`, `room_type`, `status`, `created_at`) VALUES (4, '201', 'Main Building', 40, 'lecture_hall', 'active', '2026-02-25 18:59:59');
INSERT INTO `rooms` (`id`, `room_number`, `building`, `capacity`, `room_type`, `status`, `created_at`) VALUES (5, '202', 'Main Building', 40, 'lecture_hall', 'active', '2026-02-25 18:59:59');
INSERT INTO `rooms` (`id`, `room_number`, `building`, `capacity`, `room_type`, `status`, `created_at`) VALUES (6, 'Lab 1', 'Science Wing', 25, 'lab', 'active', '2026-02-25 18:59:59');
INSERT INTO `rooms` (`id`, `room_number`, `building`, `capacity`, `room_type`, `status`, `created_at`) VALUES (7, 'Lab 2', 'Science Wing', 25, 'lab', 'active', '2026-02-25 18:59:59');
INSERT INTO `rooms` (`id`, `room_number`, `building`, `capacity`, `room_type`, `status`, `created_at`) VALUES (8, 'A101', 'Annex', 35, 'classroom', 'active', '2026-02-25 18:59:59');
INSERT INTO `rooms` (`id`, `room_number`, `building`, `capacity`, `room_type`, `status`, `created_at`) VALUES (9, 'A102', 'Annex', 35, 'classroom', 'active', '2026-02-25 18:59:59');
