INSERT INTO `students` (`id`, `user_id`, `student_id`, `grade_level`, `major`, `gpa`, `enrollment_date`, `graduation_date`) VALUES (3, 15, 'STU0015', 1, NULL, 0.00, '2026-02-25', NULL);
INSERT INTO `students` (`id`, `user_id`, `student_id`, `grade_level`, `major`, `gpa`, `enrollment_date`, `graduation_date`) VALUES (4, 16, 'STU0016', 1, NULL, 0.00, '2026-02-25', NULL);
INSERT INTO `students` (`id`, `user_id`, `student_id`, `grade_level`, `major`, `gpa`, `enrollment_date`, `graduation_date`) VALUES (5, 19, 'STU0019', 2, NULL, 0.00, '2026-02-25', NULL);
INSERT INTO `students` (`id`, `user_id`, `student_id`, `grade_level`, `major`, `gpa`, `enrollment_date`, `graduation_date`) VALUES (6, 20, 'STU0020', 2, NULL, 0.00, '2026-02-25', NULL);
INSERT INTO `students` (`id`, `user_id`, `student_id`, `grade_level`, `major`, `gpa`, `enrollment_date`, `graduation_date`) VALUES (7, 21, 'STU0021', 4, NULL, 0.00, '2026-02-25', NULL);
INSERT INTO `students` (`id`, `user_id`, `student_id`, `grade_level`, `major`, `gpa`, `enrollment_date`, `graduation_date`) VALUES (8, 22, 'STU0022', 4, NULL, 0.00, '2026-02-25', NULL);
INSERT INTO `students` (`id`, `user_id`, `student_id`, `grade_level`, `major`, `gpa`, `enrollment_date`, `graduation_date`) VALUES (9, 24, 'STU0024', 1, NULL, 0.00, '2026-02-25', NULL);
