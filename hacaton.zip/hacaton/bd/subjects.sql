INSERT INTO `subjects` (`id`, `subject_code`, `subject_name`, `description`, `department`, `is_active`, `created_at`) VALUES (1, '01', 'Math', '', 'General', 1, '2026-02-25 15:04:33');
INSERT INTO `subjects` (`id`, `subject_code`, `subject_name`, `description`, `department`, `is_active`, `created_at`) VALUES (2, '02', 'Managment', '', 'General', 1, '2026-02-25 15:04:51');
INSERT INTO `subjects` (`id`, `subject_code`, `subject_name`, `description`, `department`, `is_active`, `created_at`) VALUES (3, '03', 'Phisics', '', 'General', 1, '2026-02-25 15:05:39');
