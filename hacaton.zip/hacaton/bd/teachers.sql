INSERT INTO `teachers` (`id`, `user_id`, `teacher_id`, `department`, `position`, `hire_date`, `specialization`) VALUES (2, 17, 'TCH0017', 'General', 'Teacher', '2026-02-25', 'Manager');
INSERT INTO `teachers` (`id`, `user_id`, `teacher_id`, `department`, `position`, `hire_date`, `specialization`) VALUES (3, 18, 'TCH0018', 'General', 'Teacher', '2026-02-25', 'Match');
INSERT INTO `teachers` (`id`, `user_id`, `teacher_id`, `department`, `position`, `hire_date`, `specialization`) VALUES (4, 23, 'TCH0023', 'General', 'Teacher', '2026-02-25', 'Physics');
